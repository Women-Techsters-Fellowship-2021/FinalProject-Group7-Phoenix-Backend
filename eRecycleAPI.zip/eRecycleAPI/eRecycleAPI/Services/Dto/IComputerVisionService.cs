﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eRecycleAPI.Services.Dto;
using System.IO;
using System.Threading.Tasks;
namespace eRecycleAPI.Services.Dto
{
    public interface IComputerVisionService
    {
        Task<ImageAnalysisViewModel> AnalyzeImageUrl(string imageUrl);
    }
}
